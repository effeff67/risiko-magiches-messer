package edu.htwk.mm.risiko.model;


import lombok.AllArgsConstructor;
import lombok.Getter;

@AllArgsConstructor
@Getter
public enum Map {
    CLASSIC("ClassicMap");

    private String mapName;
}
