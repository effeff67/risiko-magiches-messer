package edu.htwk.mm.risiko;

import edu.htwk.mm.risiko.model.Color;
import edu.htwk.mm.risiko.model.Game;
import edu.htwk.mm.risiko.model.Player;
import org.springframework.boot.Banner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import java.util.Random;

@SpringBootApplication
public class RisikoAppServer {

    public static void main(String[] args) {
        Random rnd = new Random();
        SpringApplication application = new SpringApplication(RisikoAppServer.class);
        application.setBannerMode(Banner.Mode.OFF);
        application.run(args);
    }
}
