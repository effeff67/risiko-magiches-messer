package edu.htwk.mm.risiko.model;

import java.util.List;
import java.util.Random;

public enum Mission {

	CONQUER_THE_WORLD,
	ELIMINATE_PLAYER,
	OCCUPY_TWO_CONTINENTS;
	
}
