package edu.htwk.mm.risiko.model;

public enum Status {
    SUCCESS, ERROR
}
