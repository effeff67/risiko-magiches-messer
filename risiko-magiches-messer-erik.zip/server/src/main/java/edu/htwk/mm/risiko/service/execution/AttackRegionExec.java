package edu.htwk.mm.risiko.service.execution;

import edu.htwk.mm.risiko.model.Game;
import edu.htwk.mm.risiko.model.Region;
import edu.htwk.mm.risiko.model.api.GameChangeResponse;
import edu.htwk.mm.risiko.model.api.GameCommandRequest;

import java.util.List;

public class AttackRegionExec implements CommandExecutor {

    private Game game;
    private GameCommandRequest command;
    private GameChangeResponse response;
    private Region attacker;
    private Region defender;
    private int troopcount;


    public AttackRegionExec(Game game, GameCommandRequest command, GameChangeResponse response, Region attacker, Region defender, int troopcount) {
        this.game = game;
        this.command = command;
        this.response = response;
        this.attacker = attacker;
        this.defender = defender;
        this.troopcount = troopcount;
    }

    @Override
    public GameChangeResponse execute() {
        List<Integer> offensiveWerte = attacker.dice(); // player würfel-Methode implementieren
        List<Integer> defensiveWerte = defender.dice();
        return response;
    }
}
