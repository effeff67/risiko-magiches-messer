package edu.htwk.mm.risiko.service.execution;

import edu.htwk.mm.risiko.model.Game;
import edu.htwk.mm.risiko.model.GameMap;
import edu.htwk.mm.risiko.model.Player;
import edu.htwk.mm.risiko.model.api.GameChangeResponse;
import edu.htwk.mm.risiko.model.api.GameCommandRequest;

public class RecruitTroopsExec implements CommandExecutor {

    private Game game;
    private GameCommandRequest command;
    private GameChangeResponse response;
    private Player player;

    public RecruitTroopsExec(Game game, GameCommandRequest command, GameChangeResponse response, Player player) {
        this.game = game;
        this.command = command;
        this.response = response;
        this.player = player;
    }

    @Override
    public GameChangeResponse execute() {
        int k = 0;
        // Hier noch für k den gesamten Kontinetn-Truppenbonus des players errechnen, evtl. "Kontinent besetzt" als Color-Argument in Continent?
        int count = 0;
        for(int j = GameMap.getContinentList().length(); j > 0; j--){ // Anzahl der von player gehaltenen Länder
            for(int h = GameMap.getContinentList[j].getCountries().length(); h > 0; h--){
                if(GameMap.getContinentList[j].getCountries[h].getHolder() == player.getColor()){
                    count += 1;
                }
            }
        }
        int bonus = count / 3 + k;
        if(bonus < 3){
            bonus = 3; // 3 hier als Basiswert für die Truppen, die beim aufrüsten erhalten werden
        }
        return response;
    }
}
